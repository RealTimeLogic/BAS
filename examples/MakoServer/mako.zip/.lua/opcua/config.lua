local ua = require("opcua.api")
local crt = require("opcua.binary.crypto.certificate")

local function countPolicies(securePolicies, uri)
  local count = 0
  for _,policy in ipairs(securePolicies) do
    if uri == policy.securityPolicyUri then
      count = count + 1
    end
  end
  return count
end

local function checkSecurePolicies(config)
  local securePolicies = config.securePolicies
  if type(securePolicies) ~= 'table' or #securePolicies == 0 then
    return "invalid securePolicies"
  end

  local p = ua.Types.SecurityPolicy
  local modes = ua.Types.MessageSecurityMode
  for _,policy in ipairs(securePolicies) do
    local uri = policy.securityPolicyUri
    if countPolicies(securePolicies, uri) ~= 1 then
      return "security '"..tostring(policy.securityPolicyUri).."' specified multiple times"
    end
    local mode = policy.securityMode
    if uri == p.None then
      if mode == nil then
        policy.securityMode = {modes.None}
      elseif mode ~= modes.None and type(mode) ~= 'table' and #mode ~= 1 and mode[1] ~= modes.None then
        return "security mode must be None for securityPolicyUri "..tostring(policy.securityPolicyUri)
      end
    elseif uri == p.Basic128Rsa15 then
      local m
      if type(mode) == 'number' then
        m = {mode}
      elseif type(mode) ~= 'table' then
        return "security mode is not a number or array of numbers "..tostring(policy.securityPolicyUri)
      else
        m = mode
      end

      if #m > 2 then
        return "security mode can be Sign or SignAndAncrypt for policy "..tostring(policy.securityPolicyUri)
      end

      for k,v in pairs(m) do
        if type(k) ~= 'number' then
          return "security mode is not a number or array of numbers "..tostring(policy.securityPolicyUri)
        end
        if v ~= modes.SignAndEncrypt and v ~= modes.Sign then
          return "unsupported mode for securityPolicyUri "..tostring(policy.securityPolicyUri)
        end
      end
      policy.securityMode = m

      -- Try to load certificate and key
      crt.createCert(policy.certificate, config.io)
      crt.createKey(policy.key, config.io)
    else
      return "unsupported securityPolicyUri "..tostring(policy.securityPolicyUri)
    end
  end
end

local function commonConfig(config)
  if config.cosocketMode == nil then
    config.cosocketMode = ba.socket.getsock() ~= nil
  elseif type(config.cosocketMode) ~= "boolean" then
      return "invalid cosocketMode"
  end

  if config.bufSize == nil then
    config.bufSize = 65536
  elseif type(config.bufSize) ~= "number" then
    return "invalid bufSize"
  end

  if config.applicationName == nil then
    config.applicationName = 'RealTimeLogic OPCUA'
  elseif type(config.applicationName) ~= "string" then
    return "invalid applicationName"
  end

  if config.applicationUri == nil then
    config.applicationUri = "urn:realtimelogic:opcua-lua"
  elseif type(config.applicationUri) ~= "string" then
    return "invalid applicationUri"
  end

  if config.productUri == nil then
    config.productUri = "urn:realtimelogic:opcua-lua"
  elseif type(config.productUri) ~= "string" then
    return "invalid productUri"
  end

  local err = checkSecurePolicies(config)
  if err then return err end

  if config.logging == nil then
    config.logging = {}
  elseif type(config.logging) ~= 'table' then
    return "invalid logging"
  end

  if config.logging.socket == nil then
    config.logging.socket = {}
  elseif type(config.logging.socket) ~= 'table' then
    return "invalid logging.socket"
  end

  if config.logging.binary == nil then
    config.logging.binary = {}
  elseif type(config.logging.binary) ~= 'table' then
    return "invalid logging.binary"
  end

  if config.logging.services == nil then
    config.logging.services = {}
  elseif type(config.logging.services) ~= 'table' then
    return "invalid logging.services"
  end

  if config.logging.socket.dbgOn == nil then
    config.logging.socket.dbgOn = false
  elseif type(config.logging.socket.dbgOn) ~= "boolean" then
    return "invalid logging.socket.dbgOn"
  end
  if config.logging.socket.infOn == nil then
    config.logging.socket.infOn = false
  elseif type(config.logging.socket.infOn) ~= "boolean" then
    return "invalid logging.socket.infOn"
  end
  if
   config.logging.socket.errOn == nil then
    config.logging.socket.errOn = false
  elseif type(config.logging.socket.errOn) ~= "boolean" then
    return "invalid logging.socket.errOn"
  end

  if config.logging.binary.dbgOn == nil then
    config.logging.binary.dbgOn = false
  elseif type(config.logging.binary.dbgOn) ~= "boolean" then
    return "invalid logging.binary.dbgOn"
  end
  if config.logging.binary.infOn == nil then
    config.logging.binary.infOn = false
  elseif type(config.logging.binary.infOn) ~= "boolean" then
    return "invalid logging.binary.infOn"
  end
  if
   config.logging.binary.errOn == nil then
    config.logging.binary.errOn = false
  elseif type(config.logging.binary.errOn) ~= "boolean" then
    return "invalid logging.binary.errOn"
  end


  if config.logging.services.dbgOn == nil then
    config.logging.services.dbgOn = false
  elseif type(config.logging.services.dbgOn) ~= "boolean" then
    return "invalid logging.services.dbgOn"
  end
  if config.logging.services.infOn == nil then
    config.logging.services.infOn = false
  elseif type(config.logging.services.infOn) ~= "boolean" then
    return "invalid logging.services.infOn"
  end
  if
   config.logging.services.errOn == nil then
    config.logging.services.errOn = false
  elseif type(config.logging.services.errOn) ~= "boolean" then
    return "invalid logging.services.errOn"
  end
end

local function serverConfig(config)
  if type(config.endpointUrl) ~= "string" then return "invalid endpointUrl" end
  local url,err = ua.parseUrl(config.endpointUrl)
  if err then
    return err
  end

  if config.listenPort == nil then
    config.listenPort = url.port
  elseif type(config.listenPort) ~= "number" then
      return "invalid listenPort"
  end

  if config.listenAddress == nil then
    config.listenAddress = url.host
  elseif type(config.listenAddress) ~= "string" then
      return "invalid listenAddress"
  end

  return commonConfig(config)
end

return {
  client = commonConfig,
  server = serverConfig,
}
