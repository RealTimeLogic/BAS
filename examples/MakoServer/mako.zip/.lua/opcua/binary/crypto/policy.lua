local SecurityPolicy = require("opcua.types").SecurityPolicy
local fmt = string.format

local BadSecurityPolicyRejected = 0x80550000

local function init(config, io)
  assert(type(config) == 'table' and type(config[1]) == 'table', "invalid security configuration")
  local security = {}

  for _,p in ipairs(config) do
    local policyModule
    if p.securityPolicyUri == SecurityPolicy.None then
      policyModule = "opcua.binary.crypto.none"
    elseif p.securityPolicyUri == SecurityPolicy.Basic128Rsa15 then
      policyModule = "opcua.binary.crypto.basic128rsa15"
    else
      error(fmt("Unsupported policy URI %s", p.securityPolicyUri))
    end

    security[p.securityPolicyUri] = {
      policyModule = policyModule,
      securityPolicyUri = p.securityPolicyUri,
      secureMode = p.securityMode,
      certificate = p.certificate,
      key = p.key,
    }
  end

  return function(policyUri)
    local policyData = security[policyUri]
    if not policyData then
      error(BadSecurityPolicyRejected)
    end
    local policy = require(policyData.policyModule)(policyData.secureMode, io)
    policy:setLocalCertificate(policyData.certificate, policyData.key)
    return policy
  end
end

return init
