local function empty()
end

local function zero()
  return 0
end
local function size(_, sz)
  return sz
end

local function createPolicy()
  local ua = require("opcua.api")
  return {
    uri = ua.Types.SecurityPolicy.None,
    setNonces = empty,
    setSecureMode = empty,
    setLocalCertificate = empty,
    setRemoteCertificate = empty,
    asymmetricEncrypt = empty,
    asymmetricDecrypt = empty,
    symmetricEncrypt = empty,
    symmetricDecrypt = empty,
    geLocalCertLen = zero,
    getRemoteThumbLen = zero,
    aMessageSize = size,
    sMessageSize = size,
    genNonce = empty,
    localThumbprint = empty,
    remoteThumbprint = empty,
    localCert = empty,
    tailSize = function()
      return 0
    end

  }
end

return createPolicy
