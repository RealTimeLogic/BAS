local ua = require("opcua.api")
local MessageId = require("opcua.binary.message_id")
local tools = ua.Tools

local traceI = ua.trace.inf
local traceD = ua.trace.dbg
local fmt = string.format

local BadNotConnected = ua.StatusCode.BadNotConnected


local C={} -- OpcUa Client
C.__index=C

local function syncExecRequest(self, request)
  local dbgOn = self.config.logging.services.dbgOn
  if dbgOn then ua.Tools.printTable("services | execRequest", request, traceD) end

  local suc, err = pcall(self.services.sendMessage, self.services, request)
  if not suc then
    return self:processResponse(nil, err)
  end

  local resp
  suc, resp = pcall(self.services.recvMessage, self.services)
  if not suc then
    return self:processResponse(nil, resp)
  end

  return self:processResponse(resp)
end

local function coExecRequest(self, request, callback)
  local dbgOn = self.config.logging.services.dbgOn
  if dbgOn then ua.Tools.printTable("services | execRequest", request, traceD) end

  local coSock = ba.socket.getsock()
  local defCallback
  if callback == nil then
    defCallback = function(m, e)
      coSock:enable(m, e)
    end
  end
  self.requests[request.requestHeader.requestHandle] = callback or defCallback
  self.services:sendMessage(request)
  if defCallback then
    return coSock:disable()
  end
end

local function coProcessResp(self, resp, err)
  if err then
    -- Error when receiving a message. In our case it is fatal.
    -- pass error to all handlers and disconnect.
    for _, callback in pairs(self.requests) do
      callback(resp, err)
    end
    self.requests = {}
  else
    local callback = self.requests[resp.responseHeader.requestHandle]
    if callback then
      if resp.responseHeader.serviceResult ~= 0 then
        return callback(nil, resp.responseHeader.serviceResult)
      else
        return callback(resp, err)
      end
    else
      error("unknown response handle: "..resp.responseHeader.requestHandle)
    end
  end
end

local function syncProcessResp(_, resp, err)
  if resp and resp.responseHeader.serviceResult ~= 0 then
    return nil, resp.responseHeader.serviceResult
  end

  return resp, err
end

function C:connect(endpointUrl, connectCallback)
  local config = self.config
  local infOn = config.logging.services.infOn
  local services = self.services
  local coSock = ba.socket.getsock()

  if config.cosocketMode == true then
    if coSock == nil and connectCallback == nil then
      error("OPCUA: no connect callback in empty cosocket context")
    end

    if infOn then traceI(fmt("services | Connecting to endpoint '%s' in cosock mode", endpointUrl)) end
    local defCallback
    if connectCallback == nil then
      defCallback = function(err)
        coSock:enable(err)
      end
    end

    self.execRequest = coExecRequest
    self.processResp = coProcessResp
    local messageCallback = function(msg, err)
      self:processResponse(msg, err)
    end

    -- check url is valid before entering cosockets: we might hang there
    -- because of parsing URL is perofmed before first network call.
    local _,err = ua.parseUrl(endpointUrl)
    if err then
      (connectCallback or defCallback)(err)
      return err;
    end

    services:coRun(endpointUrl, connectCallback or defCallback, messageCallback)
    if defCallback ~= nil then
      if infOn then traceI(fmt("services | waiting for connection", endpointUrl)) end
      return coSock:disable()
    end
  else
    if coSock then
      error("OPCUA: can't connect in cosocket context")
    end

    if connectCallback then
      error("OPCUA: can't use callbacks in non-cosocket mode")
    end

    if infOn then traceI(fmt("services | Connecting to endpoint '%s' in synchronous mode", endpointUrl)) end
    self.execRequest = syncExecRequest
    self.processResp = syncProcessResp
    return services:connectServer(endpointUrl)
  end
end

function C:disconnect()
  local infOn = self.config.logging.services.infOn
  if self.channelTimer then
    if infOn then traceI("services | closing secure channel") end
    self:closeSecureChannel()
  end

  if infOn then traceI("Closing socket") end
  local resp, err = self.services:disconnect()
  if infOn then traceI("Disconnected") end
  return resp, err
end

function C:processResponse(msg, err)
  local infOn = self.config.logging.services.infOn
  local dbgOn = self.config.logging.services.dbgOn

  if dbgOn then
    ua.Tools.printTable("services | processingResponse", msg, traceD)
  end
  local response
  if msg then
    response = msg.body
    if msg.type == MessageId.OPEN_SECURE_CHANNEL_RESPONSE then
      if infOn then traceI("services | received OPEN_SECURE_CHANNEL_RESPONSE") end
      self:processOpenSecureChannelResponse(response)
    elseif msg.type == MessageId.CREATE_SESSION_RESPONSE then
      self:processCreateSessionResponse(response)
    end
  end

  return self:processResp(response, err)
end

function C:processOpenSecureChannelResponse(response)
  local infOn = self.config.logging.services.infOn

  local serverNonce = response.serverNonce
  self.services.enc:setNonces(self.nonce, serverNonce)
  self.services.dec:setNonces(serverNonce, self.nonce)

  self.services.dec:setSecureMode(self.securityMode)
  self.services.enc:setSecureMode(self.securityMode)

  self.services.enc:setChannelId(response.securityToken.channelId)
  self.services.enc:setTokenId(response.securityToken.tokenId)
  local timeoutMs = response.securityToken.revisedLifetime
  if infOn then traceI(fmt("services | secure channel token timeout %s", timeoutMs)) end
  timeoutMs = timeoutMs * 3 / 4
  if self.channelTimer == nil then
    self.channelTimer = ba.timer(function()
      if infOn then traceI("services | renewing secure channel token") end
      local _, err = self:renewSecureChannel(timeoutMs, function (_, err)
        if err == nil then
          if infOn then traceI("Secure channel renewed") end
        else
          if infOn then traceI(fmt("Failed to renew secure channel: %s", err)) end
        end
      end)
      return err == nil
    end)
    if infOn then traceI(fmt("services | set timer for renewing secure channel token: %s ms", timeoutMs)) end
    self.channelTimer:set(timeoutMs)
  else
    if infOn then traceI(fmt("services | reset timer for renewing secure channel token: %s ms", timeoutMs)) end
    self.channelTimer:reset(timeoutMs)
  end
end

function C:processCreateSessionResponse(response)
  local infOn = self.config.logging.services.infOn
  if infOn then
    traceI("services | received CREATE_SESSION_RESPONSE SessionId='"..response.sessionId..
          "' MaxRequestMessageSize="..response.maxRequestMessageSize..
          " AuthenticationToken='"..response.authenticationToken..
          "' RevisedSessionTimeout="..response.revisedSessionTimeout)
  end
  self.services.sessionId = response.sessionId
  self.services.sessionAuthToken = response.authenticationToken
  local policyId
  -- search for anonymous policy
  for _,endpoint in ipairs(response.serverEndpoints) do
    for _,token in ipairs(endpoint.userIdentityTokens) do
      if token.tokenType == 0 then
        policyId = token.policyId
        break
      end
    end

    if policyId ~= nil then
      break
    end
  end
  self.policyId = policyId
end

function C:openSecureChannel(timeoutMs, securityPolicyUri, securityMode, remoteCert, callback)
  assert(type(securityPolicyUri) == 'string', "no policy")
  assert(type(securityMode) == 'number', "no security mode")

  local infOn = self.config.logging.services.infOn
  if infOn then traceI("services | Opening secure channel") end
  if self.services.enc == nil then return nil, BadNotConnected end

  self.services.enc:setupPolicy(securityPolicyUri, remoteCert)
  self.nonce = self.services.enc.policy:genNonce()
  self.securityMode = securityMode

  local request, err = self.services:createRequest(MessageId.OPEN_SECURE_CHANNEL_REQUEST)
  if err then return nil, err end
  request.clientProtocolVersion = 0
  request.requestType = ua.Types.SecurityTokenRequestType.Issue
  request.securityMode = securityMode
  request.clientNonce = self.nonce
  request.requestedLifetime = timeoutMs

  return self:execRequest(request, callback)
end

function C:renewSecureChannel(timeoutMs, callback)
  local infOn = self.config.logging.services.infOn
  if infOn then traceI("services | Renew secure channel") end
  if self.services.enc == nil then return nil, BadNotConnected end

  if self.services.enc.policy then
    self.nonce = self.services.enc.policy.genNonce()
  end

  local request, err = self.services:createRequest(MessageId.OPEN_SECURE_CHANNEL_REQUEST)
  if err then return nil, err end

  request.clientProtocolVersion = 0
  request.requestType = ua.Types.SecurityTokenRequestType.Renew
  request.securityMode = ua.Types.MessageSecurityMode.None
  request.clientNonce = self.nonce
  request.requestedLifetime = timeoutMs

  return self:execRequest(request, callback)
end

function C:createSession(name, timeoutMs, callback)
  local infOn = self.config.logging.services.infOn

  if infOn then traceI("services | Creating session"..name.." timeout"..timeoutMs) end
  if self.services.enc == nil then return nil, BadNotConnected end

  local nonce
  local cert
  if self.services.enc.policy then
    nonce = self.services.enc.policy:genNonce(32)
    cert = self.services.enc.policy:localCert()
  end

  local sessionParams
  if type(name) == 'string' then
    sessionParams = {
      clientDescription = {
          applicationUri = self.config.applicationUri,
          productUri = self.config.productUri,
          applicationName = {
            text = self.config.applicationName
          },
          applicationType = ua.Types.ApplicationType.Client,
          gatewayServerUri = nil,
          discoveryProfileUri = nil,
          discoveryUrls = {},
        },
      serverUri = nil,
      endpointUrl = self.config.endpointUrl,
      sessionName = name,
      clientNonce = nonce,
      clientCertificate = cert,
      requestedSessionTimeout = timeoutMs,
      maxResponseMessageSize = 0,
    }
  else
    sessionParams = {
      clientDescription = {
          applicationUri = name.applicationUri,
          productUri = name.productUri,
          applicationName = {
            text = name.applicationName
          },
          applicationType = name.applicationType,
          gatewayServerUri = nil,
          discoveryProfileUri = nil,
          discoveryUrls = {},
        },
      serverUri = name.serverUri,
      endpointUrl = name.endpointUrl,
      sessionName = name.sessionName,
      clientNonce = nonce,
      clientCertificate = cert,
      requestedSessionTimeout = name.sessionTimeout,
      maxResponseMessageSize = 0,
    }

    callback = timeoutMs
  end

  local request, err = self.services:createRequest(MessageId.CREATE_SESSION_REQUEST, sessionParams)
  if err then return nil, err end

  return self:execRequest(request, callback)
end

function C:activateSession(params, callback)
  local infOn = self.config.logging.services.infOn
  if infOn then traceI("services | Activating session") end
  if self.services.enc == nil then return nil, BadNotConnected end

  local activateParams = {
    clientSoftwareCertificates = {},
    locales = {"en"},
    userIdentityToken = tools.createAnonymousToken(self.policyId),
    userTokenSignature = {}
  }

  if type(params) == 'table' then
    activateParams.serverCertificate = params.serverCertificate
    activateParams.serverNonce = params.serverNonce
  else
    callback = params
  end

  local policy = self.services.enc.policy
  if policy.uri ~= ua.Types.SecurityPolicy.None then
    activateParams.clientSignature = {
      algorithm = policy.aSignatureUri,
      signature = policy:asymmetricSign(params.serverCertificate, params.serverNonce)
    }
  else
    activateParams.clientSignature = {}
  end

  local request, err = self.services:createRequest(MessageId.ACTIVATE_SESSION_REQUEST, activateParams)
  if err then return nil, err end

  return self:execRequest(request, callback)
end

local function browseParams(nodeId)
  return {
    nodeId = nodeId, -- nodeId we want to browse
    browseDirection = ua.Types.BrowseDirection.Forward,
    referenceTypeId = "i=33", -- HierarchicalReferences,
    nodeClassMask = ua.Types.NodeClass.Unspecified,
    resultMask = ua.Types.BrowseResultMask.All,
    includeSubtypes = true,
  }
end

function C:browse(params, callback)
  local infOn = self.config.logging.services.infOn
  if infOn then traceI("servcies | Browsing nodes") end
  if self.services.enc == nil then return nil, BadNotConnected end

  local request = {
    nodesToBrowse = {}
  }

  -- single node ID
  if type(params) == 'string' then
    request.nodesToBrowse[1] = browseParams(params)
  -- array of nodeIDs
  elseif type(params) == 'table' and params[1] ~= nil then
    for _,nodeId in ipairs(params) do
      table.insert(request.nodesToBrowse, browseParams(nodeId))
    end
  else
    -- manual
    request = params
  end

  if request.view == nil then
    request.view = {
      viewId = ua.NodeId.Null,
      timestamp = nil, -- not specified ~1600 year
      viewVersion = 0
    }
  end
  if request.requestedMaxReferencesPerNode == nil then
    request.requestedMaxReferencesPerNode = 1000
  end

  local err
  request, err = self.services:createRequest(MessageId.BROWSE_REQUEST, request)
  if err then return request, err end

  return self:execRequest(request, callback)
end

local function allAttributes(nodeId, attrs)
  for _,val in pairs(ua.Types.AttributeId) do
    attrs[val] = {nodeId=nodeId, attributeId=val}
  end
end

function C:read(params, callback)
  local infOn = self.config.logging.services.infOn
  if infOn then traceI("services | Reading attributes") end
  if self.services.enc == nil then return nil, BadNotConnected end

  local readParams = {}
  if type(params) == 'string' then
    local attrs = {}
    allAttributes(params, attrs)
    readParams.nodesToRead = attrs
  elseif type(params) == 'table' then
    if type(params[1]) == 'string' then
      local attrs = {}
      for _,nodeId in ipairs(params) do
        allAttributes(nodeId, attrs)
      end
      readParams.nodesToRead = attrs
    else
      readParams = params
    end
  end

  if readParams.maxAge == nil then
    readParams.maxAge = 0
  end

  if readParams.timestampsToReturn == nil then
    readParams.timestampsToReturn = 0
  end

  if readParams.nodesToRead then
    for _,v in pairs(readParams.nodesToRead) do
      if v.indexRange == nil then
        v.indexRange = ""
      end
      if v.dataEncoding == nil then
        v.dataEncoding = {ns=0}
      end
    end
  end

  local request, err = self.services:createRequest(MessageId.READ_REQUEST, readParams)
  if err then return nil, err end

  return self:execRequest(request, callback)
end

function C:write(nodes, callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  local request, err = self.services:createRequest(MessageId.WRITE_REQUEST, nodes)
  if err then return nil, err end
  return self:execRequest(request, callback)
end


function C:addNodes(params, callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  local request, err = self.services:createRequest(MessageId.ADD_NODES_REQUEST, params)
  if err then return nil, err end
  return self:execRequest(request, callback)
end

function C:createSubscription(sub, callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  local request, err = self.services:createRequest(MessageId.CREATE_SUBSCRIPTION_REQUEST, sub)
  if err then return nil, err end
  return self:execRequest(request, callback)
end

function C:translateBrowsePaths(browsePaths, callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  local request, err = self.services:createRequest(MessageId.TRANSLATE_BROWSE_PATHS_TO_NODE_IdS_REQUEST,browsePaths)
  if err then return nil, err end
  return self:execRequest(request, callback)
end

function C:closeSession(callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  local infOn = self.config.logging.services.infOn
  if infOn then traceI("Closing session") end
  local closeSessionParams = {
    deleteSubscriptions = 1
  }

  local request,err = self.services:createRequest(MessageId.CLOSE_SESSION_REQUEST, closeSessionParams)
  if err then return nil, err end
  return self:execRequest(request, callback)
end

function C:closeSecureChannel()
  local infOn = self.config.logging.services.infOn
  local errOn = self.config.logging.services.errOn

  -- Just send request: there is no CloseSecureChannelResponse.
  if infOn then traceI("services | Closing secure channel") end
  if self.services.enc == nil then return BadNotConnected end

  if self.channelTimer then
    if infOn then traceI("services | Stop channel refresh timer") end
    self.channelTimer:cancel()
    self.channelTimer = nil
  end

  local request, err = self.services:createRequest(MessageId.CLOSE_SECURE_CHANNEL_REQUEST)
  if err then return err end
  if not err then
    local suc
    suc, err = pcall(self.services.sendMessage, self.services, request)
    if not suc then
      err = err
    end
  end

  if err and errOn then traceI(fmt("services | Failed to close secure channel: %s", err)) end
  return err
end

function C:findServers(params, callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  if type(params) == 'function' then
    callback = params
    params = nil
  end

  local request, err = self.services:createRequest(MessageId.FIND_SERVERS_REQUEST)
  if err then return nil, err end
  if params then
    request.endpointUrl = params.endpointUrl
  end
  request.localeIds = {}
  request.serverUris = {}

  return self:execRequest(request, callback)
end

function C:getEndpoints(params, callback)
  if self.services.enc == nil then return nil, BadNotConnected end
  if type(params) == 'function' then
    callback = params
    params = nil
  end
  local request, err = self.services:createRequest(MessageId.GET_ENDPOINTS_REQUEST, params)
  if err then return nil, err end
  request.localeIds = {}
  request.profileUris = {}

  return self:execRequest(request, callback)
end

local function NewUaClient(clientConfig, sock)
  if clientConfig == nil then
    error("no OPCUA configuration")
  end

  local uaConfig = require("opcua.config")
  local err = uaConfig.client(clientConfig)
  if err ~= nil then
    error("Configuration error: "..err)
  end

  local c = {
    config = clientConfig,
    requests = {},
    services = require("opcua.binary.client").new(clientConfig, sock),
  }
  setmetatable(c, C)
  return c
end

return {new=NewUaClient}
