--[[
 We use one global object for Xedge.
 The object has the following members:
   getNavLinks(): Returns the navigation links. Used by the theme.
   getAppLinks(): Returns the list of loaded LSP applications.
   mkio(iotype, path): Checks the path and clones the io.
   apps: A table app=apps[name], where app is the resrdr instance.
   appenvs: A table appenv=appenvs[name], where appenv is the resrdr env. (ENV)
   config: Configuration object:

 (config) data The configuration table. members:
   init: boolean set to true in .lua/configure.lsp when apps loaded
   apps: A table with the configured applications  name=app
      app: is a table with the following:
        io: The IO intf name
        name: Same as the application name, but without any non friendly
             characters. Name is used as the application name i.e. the url
             and is "" for root apps.
        path: The path to a directory or a ZIP file
        running: true|false
   save: Function called by LSP when the config table updated.

 (ENV) We save the environment table so we can run the apps onunload
 function if set.
--]]

local function log(fmt,...)
   tracep(false,5,string.format("Xedge: "..fmt, ...))
end

local xedge={
   dirs={},
   apps={},
   appenvs={},
   config={apps={},init=false, save=function() end},
   log=log
}
_G.xedge=xedge

function xedge.getStats()
   local apps = xedge.config.apps
   local tApps = 0
   local rApps=0
   for _,v in pairs(apps) do
      tApps = tApps+1
      if v.running then
         rApps = rApps+1
      end
   end
   return tApps, rApps
end


-- All objects below are 'local' to this config script.
local cfg=xedge.config
local fmt=string.format
local iovm = mako and io or ba.openio("vm")

-- The LSP pages in the Xedge.
local navUris = {
   "application-list.lsp",
   "new-application.lsp",
   "help.lsp",
}

-- This list must have the same size and have the same order as navUris
local navNames = {
   "Application List",
   "New Application",
   "Help",
}

-- A table version of the navUris array.
-- Used by the directory function for "URI validation check"
local navUrisK = {}
for k,v in ipairs(navUris) do
   navUrisK[v]=navNames[k]
end

-- The theme calls this function when emitting the navlinks
local function getNavLinks()
   local function getUri(k)
      return '/rtl/appmgr/'..navUris[k]
   end
   return navNames, getUri
end
xedge.getNavLinks=getNavLinks

local function getAppLinks()
end
xedge.getAppLinks=getAppLinks


local function emitBusy(response, content, redirUrl)
   local fp = iovm:open(".busy.txt", "r")
   if fp then
      response:reset"buffer"
      response:write(fmt(fp:read("*a"), redirUrl and redirUrl or "", content))
      fp:close()
      response:flush()
      response:abort()
   end
end
xedge.emitBusy=emitBusy

local function mkio(iotype, path, mustBeDir)
   local io = ba.openio(iotype)
   if io then
      local st,errCode,errMsg = io:stat(path)
      if st then
         if not st.isdir and mustBeDir then
            return nil, "notfound", "Not a directory"
         end
         local dupio,errCode=ba.mkio(io, path)
         if dupio then
            return dupio
         end
         return nil, errCode, "Cannot duplicate IO"
      end
      return nil, errCode,errMsg
   end
   return nil, "notfound", "Invalid IO name"
end
xedge.mkio=mkio

local function cfgStopApp(name, nosave)
   assert(cfg.init)
   local function stop(app)
      if app then
         local resrdr = xedge.apps[app.name]
         if resrdr then
            xedge.apps[app.name]=nil
            local appenv=xedge.appenvs[app.name]
            xedge.appenvs[app.name]=nil
            resrdr:unlink()
            local func = appenv and rawget(appenv,"onunload")
            if type(func) == "function" then
               local ok, e = pcall(func)
               if not ok then
                  log("Stopping LSP app '%s' failed: %s",name,e or "?")
               end
            end
            if not nosave then
               app.running=false
               cfg.save()
            end
            resrdr,appenv,func=nil,nil,nil
            collectgarbage() collectgarbage() collectgarbage()
            return true
         end
      end
      return nil, "Cannot find "..app.name
   end
   local apps=cfg.apps
   if name then
      return stop(apps[name])
   else
      for name,app in pairs(apps) do
         if app.running then
            stop(app)
         end
      end
   end
   return true
end
cfg.stopApp=cfgStopApp


local function errh(emsg)
   return debug and debug.traceback and debug.traceback(emsg,2) or emsg
end

local function cfgStartApp(name)
   assert(cfg.init)
   local apps=cfg.apps
   function start(app)
      local io,err = mkio(app.iotype, app.path)
      if io then
         app.io=io
         local rootapp = #app.name == 0 and true or false
         local resrdr=ba.create.resrdr(
            not rootapp and app.name or nil,app.prio,io)
         if resrdr then
            -- Directory must be inserted before ".preload" to make
            -- dir:baseuri work properly when .preload is run.
            if rootapp then
               resrdr:insert()
            else
               xedge.dirs.rootDir:insert(resrdr)
            end
            local ok=true
            local appenv
            if io:stat".preload" then
               local f
               appenv=setmetatable({io=io,dir=resrdr},{__index=_G})
               appenv.app = appenv
               f,err = io:loadfile(".preload",appenv)
               if f then
                  ok, err = xpcall(f,errh)
                  if ok then err=nil end
               end
            else
               print(fmt("Info: %s/.preload not found",app.path))
            end
            resrdr:lspfilter(appenv)
            xedge.apps[app.name]=resrdr
            xedge.appenvs[app.name]=appenv
            app.running=true
            cfg.save()
            if not err then return true end
            return nil,(err or ".preload failed")
         else
            err="Cannot create resrdr"
         end
      end
      return nil,err
   end
   if name then
      local app=apps[name]
      if app then
         return start(app)
      end
      return nil, "Not found"
   else
      for name,app in pairs(apps) do
         if app.running then
            local ok, err = start(app)
            if not ok then
               app.running=false
               log("Cannot start %s: %s", name, err)
            end
         end
      end
   end
end
cfg.startApp=cfgStartApp


local rootDir=ba.create.dir()
rootDir:insert() -- Insert as a VFS root directory
xedge.dirs.rootDir=rootDir

local rtlDir=ba.create.resrdr('rtl', iovm)
-- used by fb.lsp
local iot=setmetatable({},{__mode='v'})
local function getio(name)
   local app = cfg.apps[name]
   if app then
      if app.io and app.io ~= ba.json.null then
         return app.io,name
      end
      return
   end
   local io = iot[name]
   if not io then
      pcall(function()
               local x=ba.json.decode(ba.b64decode(name))
               io=x.path=="/" and ba.openio(x.io) or ba.mkio(ba.openio(x.io),x.path)
               iot[name]=io
            end)
   end
   return io,""
end
local function mkdef(fp, ext)
   if fp then
      local f = iovm:open("templates/template."..ext)
      if f then
         fp:write(f:read("*a"))
         f:close()
      end
      fp:close()
   end
end
rtlDir:lspfilter({getio=getio,mkdef=mkdef}) -- LSP enable the Resource Reader.
rootDir:insert(rtlDir,true) -- Insert into root and make available as '/rtl'/
xedge.dirs.rtlDir=rtlDir

if ba.create.tracelogger then
   pcall(function() rtlDir:insert(ba.create.tracelogger(),true) end)
end

-- Our Xedge Mini Content Management System

local xedgeBusy=false
local function forward(response,url)
   xedgeBusy = true
   response:forward(url, true)
   xedgeBusy = false
end

local function checkBusy(_ENV)
   if xedgeBusy then
      emitBusy(response,"<h1>Xedge busy: try later</h1><p>Another client is configuring the Application Manager</p>")
      return true
   end
   return false
end

xedge.checkBusy=checkBusy
xedge.forward=forward



local function appFunc(_ENV,relpath)
   if checkBusy(_ENV) then return end
   -- Declared in the call scope. Used by the HTML theme.
   function getTitle()
      return navUrisK[relpath]
   end
   function emitBody() -- Used by the theme
      response:include("/rtl/.lua/"..relpath)
   end
   if cfg.init then
      if navUrisK[relpath] then -- If valid URI
         forward(response,"/rtl/theme/.theme.lsp")
      else
         response:sendredirect"/rtl/appmgr/help.lsp"
      end
   else
      forward(response,"/rtl/.lua/configure.lsp")
   end
end

local appmgrDir=ba.create.dir('appmgr')
appmgrDir:setfunc(appFunc)
rtlDir:insert(appmgrDir)
xedge.dirs.luaDir=appmgrDir

local davm={
PROPFIND=true,
OPTIONS=true
}

local useredir
local function notFoundFunc(_ENV, relpath)
   if davm[request:method()] then
      return false
   end
   if useredir then
      local uri=request:uri()
      if not uri:find"/$" and not uri:find".lsp$" and not uri:find".html$" then
         if relpath:find("^rtl/") or relpath == "favicon.ico" then
            response:sendredirect("https://realtimelogic.com/resources.v4/"..relpath, true)
         end
         log("rtl resource not found: /"..relpath)
         return false
      end
   end
   log(fmt("page /%s not found using method %s",relpath,request:method()))
   if relpath:find("^rtl/") then
      response:sendredirect"/rtl/appmgr/help.lsp"
   else
      function getTitle()
         return "Page Not Found"
      end
      function emitBody() -- Used by the theme
         response:include("/rtl/.notfound.lsp")
      end
      response:setstatus(404)
      response:forward"/rtl/theme/.theme.lsp"
   end
end
useredir = not iovm:stat"ide/ide.js"
local notFoundDir=ba.create.dir(-128)
notFoundDir:setfunc(notFoundFunc)
notFoundDir:insert()
xedge.dirs.notFoundDir=notFoundDir
